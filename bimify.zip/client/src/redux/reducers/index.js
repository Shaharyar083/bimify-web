import productSlice from "./product-reducer";
import userSlice from "./user-reducer";

export { userSlice, productSlice };
