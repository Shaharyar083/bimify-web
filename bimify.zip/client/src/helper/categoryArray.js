import pic1 from "../assets/image/1.png";
import pic2 from "../assets/image/2.png";
import pic3 from "../assets/image/3.png";
import pic4 from "../assets/image/4.png";
import pic5 from "../assets/image/5.png";
import pic6 from "../assets/image/6.png";
import pic7 from "../assets/image/7.png";
import pic8 from "../assets/image/8.png";
import pic9 from "../assets/image/9.png";
import pic10 from "../assets/image/10.png";
import pic11 from "../assets/image/11.png";
import pic12 from "../assets/image/12.png";
import pic13 from "../assets/image/13.png";
import pic14 from "../assets/image/14.png";
import pic15 from "../assets/image/15.png";
import pic16 from "../assets/image/16.png";
import pic17 from "../assets/image/17.png";
import pic18 from "../assets/image/18.png";
import pic19 from "../assets/image/19.png";
import pic20 from "../assets/image/20.png";
import pic21 from "../assets/image/21.png";
import pic22 from "../assets/image/22.png";

export const category = [
  {
    name: "Kitchen",
    image: pic1,
  },
  {
    name: "Lighting",
    image: pic2,
  },
  {
    name: "Sanitary",
    image: pic3,
  },
  {
    name: "Doors",
    image: pic4,
  },
  {
    name: "Windows",
    image: pic5,
  },
  {
    name: "Furniture",
    image: pic6,
  },
  {
    name: "Electrical",
    image: pic7,
  },
  {
    name: "Plumbing",
    image: pic8,
  },
  {
    name: "Fire Products",
    image: pic9,
  },
  {
    name: "HVAC",
    image: pic10,
  },
  {
    name: "Casework",
    image: pic11,
  },
  {
    name: "Electronics",
    image: pic12,
  },
  {
    name: "Construction",
    image: pic13,
  },
  {
    name: "Flooring",
    image: pic14,
  },
  {
    name: "Railing & Fences",
    image: pic15,
  },
  {
    name: "Building Elements & Modules",
    image: pic16,
  },
  {
    name: "Circulation",
    image: pic17,
  },
  {
    name: "Medical & Research Equipment",
    image: pic18,
  },
  {
    name: "Outdoor Furniture",
    image: pic19,
  },
  {
    name: "Planting",
    image: pic20,
  },
  {
    name: "Signage",
    image: pic21,
  },
  {
    name: "WasteRecycling",
    image: pic22,
  },
];
