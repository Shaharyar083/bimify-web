import brand1 from "../assets/image/brand.png";

export const brands = [
  {
    image: brand1,
  },
];
