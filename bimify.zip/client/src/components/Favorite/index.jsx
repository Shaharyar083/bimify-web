import FavoritePage from "./FavoritePage";

export default FavoritePage;
